<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Questions
        <small>Be careful</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Add questions in paper</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
          Start creating your amazing application!
          <?php echo $this->session->role; ?>

<h1>jQuery add / remove textbox </h1>

<script type="text/javascript">

$(document).ready(function(){

    var counter = 2;
    
    $("#addButton").click(function () {
        
  if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
  }   
    
  var newTextBoxDiv = $(document.createElement('div'))
       .attr("id", 'TextBoxDiv' + counter);
                
  newTextBoxDiv.after().html('<label>Textbox #'+ counter + ' : </label>' +
        '<input type="text" name="textbox' + counter + 
        '" id="textbox' + counter + '" value="" >');
            
  newTextBoxDiv.appendTo("#TextBoxesGroup");

        
  counter++;
     });

     $("#removeButton").click(function () {
  if(counter==1){
          alert("No more textbox to remove");
          return false;
       }   
        
  counter--;
      
        $("#TextBoxDiv" + counter).remove();
      
     });
    
     $("#getButtonValue").click(function () {
    
  var msg = '';
  for(i=1; i<counter; i++){
      msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
  }
        alert(msg);
     });
  });
</script>


</head><body>

<div id='TextBoxesGroup'>
  <div id="TextBoxDiv1">
    <label>Textbox #1 : </label><input type='textbox' id='textbox1' >
  </div>
</div>
<input type='button' value='Add Button' id='addButton'>
<input type='button' value='Remove Button' id='removeButton'>
<input type='button' value='Get TextBox Value' id='getButtonValue'>



<!--

<script type="text/javascript">

var changeHandled = [].slice.call(document.querySelectorAll('.change-handled'));
var total = document.querySelector('.total');

function calc() {
    total.textContent = changeHandled.reduce(function(total, el) { 
      return total += Number(el.value);
    }, 0);
}
  
changeHandled.forEach(function(el) {
   el.onblur = calc;
});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<input type="number" class="change-handled">
<input type="number" class="change-handled">
<input type="number" class="change-handled">

Total: $<span class="total">0</span>


-->
<!--
<script>
$('body').on('blur', 'input.change-handled', UpdateTotal);

function UpdateTotal() {
    var total = 0;
    var $changeInputs = $('input.change-handled');
    $changeInputs.each(function(idx, el) {
      total += Number($(el).val());
      });
  
  $('.total').text(total);
}
</script>

<input type="number" class="change-handled">
<input type="number" class="change-handled">
<input type="number" class="change-handled">

Total: $<span class="total">0</span>
-->

<script type="text/javascript">
$(function() {
$("input.Qty").keyup(function(){
  sumValues();
}).keyup();
});
function sumValues() {
    var sum = 0;

    $("input.Qty").each(function(){
        var $this = $(this);
        var amount = parseInt($this.val(), 10);
        sum += amount === "" || isNaN(amount)? 0 : amount;
    });

    $("#qtybox").text(sum);
}

</script>
<input class="Qty" value="10"/>
<input class="Qty" value="11"/>
<input class="Qty" value="13"/>
<input class="Qty" value="14"/>
<input class="Qty" value="6"/>
<input class="Qty" value="8"/>

<div id="qtybox"></div>

        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          Footer
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
