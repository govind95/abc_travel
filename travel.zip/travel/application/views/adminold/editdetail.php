<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit user details
        <small>You can change according to your need !!</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">


      <!-- Default box -->
      <div class="box">
<?php foreach($result  as $r): ?>

        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo $r->username; ?> </h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body  col-xs-8">
         
 <?php 

  if(isset($message_error) && $message_error){
          echo '<div class="alert alert-danger fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Something wrong!</strong> Change a few things up and try submitting again.';
          echo '</div>';             
      }

      $attributes = array('class' => 'form-signin');

 echo form_open('admin/users/updatedetail', $attributes);


echo  '<div class="form-group has-feedback">';
 echo form_input('email', $r->username, 'placeholder="Email" class="form-control"');
 echo '<span class="glyphicon glyphicon-envelope form-control-feedback"></span> </div>';

echo  '<div class="form-group has-feedback">';
 echo form_password('password', '', 'placeholder="Password" class="form-control"');
 echo '<span class="glyphicon glyphicon-lock form-control-feedback"></span> </div>';


     echo '<div class="col-xs-4">';
 echo form_submit('submit', 'Signin', 'class="btn btn-primary btn-block btn-flat"');
echo '</div></div>';
      echo form_close();

?>


        </div>
        <!-- /.box-body -->
<?php endforeach; ?>
 
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
