<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Full Paper Details
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Detailed View of Paper</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            
          </div>
        </div>
        <div class="box-body">
         
<?php 
if(isset($_GET['success'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Question Update successfully.';
          echo '</div>';
}
?>
<?php foreach($result as $m): ?>
<table class="table table-hover">
<tbody>
<tr><td width="250px"><b>Paper name</b></td><td><?php echo $m->name; ?></td></tr>
<tr><td width="250px"><b>Maximum Mark</b></td><td><?php echo $m->maxmark; ?></td></tr>
<tr><td width="250px"><b>Maximum Questions</b></td><td><?php echo $m->maxquestion; ?></td></tr>
<tr><td width="250px"><b>Marks Per Question</b></td><td><?php echo $m->questionmark; ?></td></tr>
<tr><td width="250px"><b>Negative Marks Per Question</b></td><td><?php echo $m->negativemark; ?></td></tr>
<tr><td width="250px"><b>Paper Duration</b></td><td><?php echo $m->time; ?></td></tr>
<tr><td width="250px"><b>Start Date - End Date</b></td><td><?php echo $m->startdate; echo " - "; echo $m->enddate; ?></td></tr>
<tr><td width="250px"><b>Price</b></td><td><?php echo $m->price; ?></td></tr>
<tr><td width="250px"><b>Added date</b></td><td><?php echo $m->adddate; ?></td></tr>
<tr><td width="250px"><b>Paper Duration</b></td><td><?php echo $m->time; ?></td></tr>

<tr><td width="250px"><b>Paper Status</b></td><td><?php if($m->status==1){echo "Active";}else{echo "Deactive";} ?></td></tr>
<tr><td width="250px"><b>Paper Status on Site</b></td><td><?php if($m->f_status==1){echo "Active";}else{echo "Deactive";} ?></td></tr>
<tr><td width="250px"><b>Uploaded by</b></td><td><a href="#"><?php echo $m->editor_name; ?></a></td></tr>
</tbody>
</table>
<?php endforeach;?>


        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          Footer
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
