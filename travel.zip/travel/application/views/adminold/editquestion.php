<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Question Details
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Question details</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
           
          </div>
        </div>
        <div class="box-body">
 



 <div class="row">
            <div class="col-md-6">
             

<script type="text/javascript">
                   //<![CDATA[
                        base_url = '<?php echo base_url();?>';
                   //]]>
                </script>

<script type="text/javascript">
$(document).ready(function()
{
$("#maincatid").change(function()
{
var id=$(this).val();
var dataString = 'id='+ id;

$.ajax
({
type: "POST",
url: "http://localhost/mainexamproject/index.php/admin/questions/showsubcatlist/",
data: dataString,
cache: false,
success: function(html)
{
$("#subcat").html(html);
} 
});

});

});
</script>
<?php foreach($eqd as $gt):?>
<?php
echo validation_errors();
 echo form_open('admin/questions/updatequestion');


echo '<div class="form-group">';
echo ' <label>Main Category</label>';
echo '<select name="maincatid" id="maincatid"class="form-control select2" required>';
echo "<option value='$gt->cat'> $gt->mcname</option>";
foreach ($result as $r) {
echo "<option value=" . $r->id . ">" . $r->name . "</option>";
                      }
echo '</select></div>';

echo  '<div class="form-group">';
echo form_textarea('eqd', "$gt->questiondetails",'id="compose-textarea" class="form-control" style="height: 100px" placeholder="Question in English" required');

echo '</div>';


echo '<div class="row">';


echo '<div class="col-xs-6">';
echo '<label>Correct Answer</label>';
echo form_input('correct_answer',"$gt->answer",'class="form-control" placeholder="Correct Answer in English" required');         

echo '</div>';
echo '<div class="col-xs-6">';
echo '<label>Question ID</label>';
echo form_input('qid',"$gt->id",'class="form-control" readonly required');         

echo '</div> </div><br>';
echo '<div class="row">';
echo '<div class="col-xs-7">';
echo form_submit('submit','Click here to Update this Question','class="btn btn-primary btn-block tn-flat"');



echo "</div></div>";
echo ' </div>
            <!-- /.col -->
            <div class="col-md-6">';

 echo '<div class="col-md-6">
<div class="form-group">
                <label>Sub Category</label>';
echo ' <select name="subcat" id="subcat" class="form-control select2" style="width: 100%;">';
                 
                  echo "<option value='$gt->subcat'> $gt->scname</option>";
                 
    echo '</select>
              </div>
              <!-- /.form-group --> </div>';

echo '<div class="col-md-6">
<div class="form-group">
                <label>Level</label>
                <select name="ql" id="ql" class="form-control select2" style="width: 100%;">';
                 echo "<option value='$gt->level'> $gt->levelname </option>";
                  

                   echo '<option value="1">Too simple</option>
                   <option value="2">Simple</option>
                     <option value="3">Hard</option>
                      <option value="4">Too hard</option>                 
                </select>
              </div>
              <!-- /.form-group -->
</div>';

echo  '<div class="form-group">';
 echo form_textarea('hqd', "$gt->questiondetails_hindi", 'id="compose-textarea-hindi" class="form-control" style="height: 100px" placeholder="Question in Hindi"');

echo '</div>';

echo '<div class="row">';
                
                

                
       echo '
<!-- row -->
              
            </div>
            <!-- /.col -->
        ';

echo form_close();
?>


<?php endforeach; ?>
  </div>
          <!-- /.row -->


        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          <font color="red">All Required * </font>
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
