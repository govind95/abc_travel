<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Questions
        <small>add question section</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Add New Question</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
           
          </div>
        </div>
        <div class="box-body">
        
<?php 
if(isset($_GET['success'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Question addedd successfully.';
          echo '</div>';
}
?>



 <div class="row">
            <div class="col-md-6">
             

<script type="text/javascript">
                   //<![CDATA[
                        base_url = '<?php echo base_url();?>';
                   //]]>
                </script>

<script type="text/javascript">
$(document).ready(function()
{
$("#maincatid").change(function()
{
var id=$(this).val();
var dataString = 'id='+ id;

$.ajax
({
type: "POST",
url: "http://localhost/mainexamproject/index.php/admin/questions/showsubcatlist/",
data: dataString,
cache: false,
success: function(html)
{
$("#subcat").html(html);
} 
});

});

});
</script>

<?php
echo validation_errors();
 echo form_open('admin/questions/addquestion');


echo '<div class="form-group">';
echo ' <label>Main Category</label>';
echo '<select name="maincatid" id="maincatid"class="form-control select2" required>';
echo '<option>Select main Category</option>';
foreach ($result as $r) {
echo "<option value=" . $r->id . ">" . $r->name . "</option>";
                      }
echo '</select></div>';


echo  '<div class="form-group">';
 echo form_textarea('eqd', '','id="compose-textarea" class="form-control" style="height: 100px" placeholder="Question in English" required');

echo '</div>';

 echo '<div class="row">
                  <div class="col-xs-6">';
echo form_input('option_a','','class="form-control" placeholder="Option A in English" required');         

echo '</div> ';
 echo ' <div class="col-xs-6">';
echo form_input('option_b','','class="form-control" placeholder="Option B in English" required');         

echo '</div></div> <!-- row --> <br>';
 echo '<div class="row">
                  <div class="col-xs-6">';
echo form_input('option_c','','class="form-control" placeholder="Option C in English" required');         

echo '</div>';
 echo '<div class="col-xs-6">';
echo form_input('option_d','','class="form-control" placeholder="Option D in English" required');         

echo '</div></div> <!-- row --> <br>';

echo '<div class="row">';


echo '<div class="col-xs-5">';
echo form_input('correct_answer','','class="form-control" placeholder="Correct Answer in English" required');         

echo '</div>';


echo '<div class="col-xs-7">';
echo form_submit('submit','Click here to Add this Question','class="btn btn-primary btn-block tn-flat"');



echo "</div></div>";
echo ' </div>
            <!-- /.col -->
            <div class="col-md-6">';

 echo '<div class="col-md-6">
<div class="form-group">
                <label>Sub Category</label>';
echo ' <select name="subcat" id="subcat" class="form-control select2" style="width: 100%;">
                  <option selected="selected">Select Sub category</option>
                 
                </select>
              </div>
              <!-- /.form-group --> </div>';

echo '<div class="col-md-6">
<div class="form-group">
                <label>Level</label>
                <select name="ql" id="ql" class="form-control select2" style="width: 100%;">
                  <option selected="selected">Select Question Level</option>
                    <option value="1">Too simple</option>
                   <option value="2">Simple</option>
                     <option value="3">Hard</option>
                      <option value="4">Too hard</option>                 
                </select>
              </div>
              <!-- /.form-group -->
</div>';

echo  '<div class="form-group">';
 echo form_textarea('hqd', '', 'id="compose-textarea-hindi" class="form-control" style="height: 100px" placeholder="Question in Hindi"');

echo '</div>';

echo '<div class="row">';
                
                
  
echo ' <div class="col-xs-6">';
echo form_input('option_h_a','','class="form-control" placeholder="Option A in Hindi" required');         

echo '</div>';
 echo ' <div class="col-xs-6">';
echo form_input('option_h_b','','class="form-control" placeholder="Option B in Hindi" required');         

echo '</div></div> <br>';

echo '<div class="row">
  <div class="col-xs-6">';
echo form_input('option_h_c','','class="form-control" placeholder="Option C in Hindi" required');
echo '</div>';

 echo ' <div class="col-xs-6">';
echo form_input('option_h_d','','class="form-control" placeholder="Option D in Hindi" required');         

echo '</div></div> ';

                
       echo '
<!-- row -->
              
            </div>
            <!-- /.col -->
        ';

echo form_close();
?>


             
           
              
 
               

 




 





  </div>
          <!-- /.row -->


        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          <font color="red">All Required * </font>
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
