<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Categories Section
        <small>Add View & Edit</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add Main Category</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->


 <?php 

  if(isset($message_error) && $message_error){
          echo '<div class="alert alert-danger fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Something wrong!</strong> Change a few things up and try submitting again.';
          echo '</div>';             
      }
if(isset($_GET['maincat']))
{
echo '<div class="alert alert-danger fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Sorry!</strong> Category Already Exists. Please check and try again.';
          echo '</div>';

}
if(isset($_GET['maincatsuccess'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Category addedd successfully.';
          echo '</div>';
}
     

 echo form_open('admin/categories/addnewcat');
echo '<div class="box-body">';


echo  '<div class="form-group has-feedback">';
 echo form_input('catname', '', 'placeholder="Main category name" class="form-control" Required');
 echo '</div>';

echo  '<div class="form-group has-feedback">';
 echo form_textarea('catdetails', '', 'placeholder="Main Category Details " class="form-control" Required');
 echo ' </div>';

echo  '<div class="row">';

     echo '<div class="col-xs-4">';
 echo form_submit('submit', 'Click here to Add', 'class="btn btn-primary btn-block btn-flat"');
echo '</div></div>';
      echo form_close();

?>

</div>

</div>
           
          <!-- /.box -->


 <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add Sub Category</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->


 <?php 

  if(isset($message_error) && $message_error){
          echo '<div class="alert alert-danger fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Something wrong!</strong> Change a few things up and try submitting again.';
          echo '</div>';             
      }
if(isset($_GET['subcat']))
{
echo '<div class="alert alert-danger fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Sorry!</strong> Category Already Exists. Please check and try again.';
          echo '</div>';

}
if(isset($_GET['subcatsuccess'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Sub Category addedd successfully.';
          echo '</div>';
}
     

 echo form_open('admin/categories/addnewsubcat');
echo '<div class="box-body">';

echo '<div class="form-group">';
echo '<select name="maincatid" id="maincatid"class="form-control">';
echo '<option value="0">Select Main Category</option>';
foreach ($result as $r) {
echo "<option value=" . $r->id . ">" . $r->name . "</option>";
                      }
echo '</select></div>';

echo  '<div class="form-group has-feedback">';
 echo form_input('subcatname', '', 'placeholder="Sub category name" class="form-control" Required');
 echo '</div>';

echo  '<div class="form-group has-feedback">';
 echo form_textarea('subcatdetails', '', 'placeholder="Sub Category Details " class="form-control" Required');
 echo ' </div>';

echo  '<div class="row">';

     echo '<div class="col-xs-4">';
 echo form_submit('submit', 'Click here to Add', 'class="btn btn-primary btn-block btn-flat"');
echo '</div></div>';
      echo form_close();

?>

</div>

</div>
           








        </div>
        <!--/.col (left) -->




        <!-- right column -->
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Available Main Categories</h3>
            </div>
            <!-- /.box-header -->
            <table class="table table-bordered">
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Main Category Name</th>
                  <th>Total Question</th>
<th>Status</th>
                  <th style="width: 40px">Actions</th>
                </tr>
               
<?php $sn=1; foreach($result as $r): ?>
 <tr>
<td><?php echo $sn; ?></td>
                  <td><?php echo $r->name; ?></td>
                  <td>
<?php echo $r->totalquestion; ?>                   </td>
<td><?php if($r->status==1){ echo '<span class="label label-success">Active</span>';} else {echo '<span class="label label-success">Deactive</span>';}?>  </td>
                  <td><span class="label label-primary">Click here for edit</span></td>
                </tr>


<?php $sn=$sn+1; endforeach; ?>
                  
                
              </table>

          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Sub Categories</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
 


<?php  

echo form_open('admin/categories/showsubcategory');
echo '<div class="form-group">';
echo '<select name="maincatid" id="maincatid"class="form-control">';
echo '<option value="0">Select Main Category from list</option>';
foreach ($result as $r) {
echo "<option value=" . $r->id . ">" . $r->name . "</option>";
                      }
echo '</select></div>';



 echo form_submit('submit', 'Click here to see Sub Category', 'class="btn btn-primary btn-block btn-flat"');

      echo form_close();

?>

<?php if(isset($subcatlist)) {  ?>
<table class="table table-bordered">
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Sub Category Name</th>
                  <th>Total Question</th>
<th>Status</th>
                  <th style="width: 40px">Actions</th>
                </tr>
               
<?php $sn=1; foreach($subcatlist as $r): ?>
 <tr>
<td><?php echo $sn; ?></td>
                  <td><?php echo $r->name; ?></td>
                  <td>
<?php echo $r->totalquestion; ?>                   </td>
<td><?php if($r->status==1){ echo '<span class="label label-success">Active</span>';} else {echo '<span class="label label-success">Deactive</span>';}?>  </td>
                  <td><span class="label label-primary">Click here for edit</span></td>
                </tr>


<?php $sn=$sn+1; endforeach; ?>
                  
                
              </table>

<?php } ?>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
































