<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Final Papers List
        <small>All papers included in this List.</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Final Paper List</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
           
          </div>
        </div>
        <div class="box-body">
     
<?php 
if(isset($_GET['deletesuccess'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Requested paper Deactive successfully.';
          echo '</div>';
}
if(isset($_GET['actsuccess'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Requested Paper Active successfully.';
          echo '</div>';
}

// Get Flash data on view 
echo $this->session->flashdata('message');

?>
 <table id="example1" class="table table-bordered table-striped">
<thead>
                <tr>
                  <th style="width: 10px">#</th>
                    <th>Name</th>
                    <th>Max. Mark</th>
                   
                    
                    <th>Total Question</th>
                    <th>Final Questions in Paper</th>
                    <th>Duration</th>
                     <th>Added By</th>
                    <th>Status</th>
                  <th style="width: 80px">Actions</th>
                </tr>
               </thead>
<?php $sn=1; foreach($result as $r): ?>
 <tr>
<td><?php echo $sn; ?></td>
                  <td><?php echo $r->name; ?></td>
                  <td><?php echo $r->maxmark; ?>  </td>
  
 
 <td><?php echo $r->maxquestion; ?>  </td>
 <td><?php echo $r->csqc; if(!$r->maxquestion == $r->csqc) {?>  

  <a href="finalqadd/<?php echo $r->id; ?>" title="Click here to Add Questions in Paper"><button type="button" class="btn btn-xs btn-success">  <span class="glyphicon glyphicon-plus"></span></button></a>
<?php } ?>
</td>
  <td><?php echo $r->time; ?>  </td>
   <td><?php echo $r->editor_name; ?>  </td>
<td><?php if($r->f_status==1){ echo '<span class="label label-success">Active</span>';} else {echo '<span class="label label-danger">Deactive</span>';}?>  </td>
<td>
<?php if($r->maxquestion == $r->csqc) {
if($r->f_status==1) { ?>

<a href="papers/delete/<?php echo $r->id; ?>" title="Click here to Deactive"><button type="button" class="btn btn-xs btn-danger">  <span class="glyphicon glyphicon-ban-circle"></span></button></a>

<?php }
else{  ?>
<a href="papers/active/<?php echo $r->id; ?>" title="Click here to Active"><button type="button" class="btn btn-xs btn-success">  <span class="glyphicon glyphicon-ok"></span></button></a>
<?php }


}
else {echo ' <small class="label label-warning">Final count Missing</small>';}?>



                  </td>
                </tr>


<?php $sn=$sn+1; endforeach; ?>
                  
                
              </table>











        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          Footer
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
