<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Full Question Detail
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Detailed View of Question</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
         
<?php 
if(isset($_GET['success'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Question Update successfully.';
          echo '</div>';
}
?>
<?php foreach($result as $m): ?>
<table class="table table-hover">
<tbody>
<tr><td width="200px"><b>Question in English</b></td><td><?php echo $m->questiondetails; ?></td></tr>
<tr><td width="200px"><b>Question in Hindi</b></td><td><?php echo $m->questiondetails_hindi; ?></td></tr>
<tr><td width="200px"><b>Main Category</b></td><td><?php echo $m->mcname; ?></td></tr>
<tr><td width="200px"><b>Sub Category</b></td><td><?php echo $m->scname; ?></td></tr>
<tr><td width="200px"><b>Question Level</b></td><td><?php echo $m->levelname; ?></td></tr>
<tr><td width="200px"><b>Correct Answer</b></td><td><?php echo $m->answer; ?></td></tr>
<tr><td width="200px"><b>Added Date</b></td><td><?php echo $m->date; ?></td></tr>
<tr><td width="200px"><b>Status</b></td><td><?php if($m->status==1){echo "Active";}else{echo "Deactive";} ?></td></tr>
<tr><td width="200px"><b>Uploaded by</b></td><td><a href="#"><?php echo $m->editor_name; ?></a></td></tr>
<tr><td width="200px"><b>Available Options</b></td><td>
<tr style="color : white; background-color : #031513;"><td><b>Options in English</b></td><td><b>Options in Hindi</b></td></tr>

<?php foreach($result2 as $t):?>
  <tr><td><?php echo $t->answerdetail; ?></td><td><?php echo $t->answerdetail_hindi; ?></td></tr>
<?php endforeach;?>



</td></tr>
</tbody>
</table>
<?php endforeach;?>


        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          Footer
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
