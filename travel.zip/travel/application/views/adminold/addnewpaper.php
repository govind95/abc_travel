<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Paper
        <small>add paper section</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Add New Paper</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
           
          </div>
        </div>
        <div class="box-body">
        
<?php 
if(isset($_GET['success'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Question addedd successfully.';
          echo '</div>';
}
?>



 <div class="row">
            <div class="col-md-6">
            



<?php
echo validation_errors();
 echo form_open('admin/papers/addpaper');


echo '<div class="form-group">';
echo ' <label>Paper Type</label>';
echo '<select name="ptype" id="ptype"class="form-control select2" required>';
echo '<option>Select paper type</option>';
foreach ($result as $r) {
echo "<option value=" . $r->id . ">" . $r->name . "</option>";
                      }
echo '</select></div>';

echo '<div class="form-group">';
echo ' <label>Paper Name</label>';
echo form_input('pname','','class="form-control" placeholder="Enter Paper name" required');         

echo '</div> ';
echo  '<div class="form-group">';
 echo form_textarea('pd', '','id="compose-textarea" class="form-control" style="height: 100px" placeholder="Paper Instruction" required');

echo '</div>';

 
 

echo '<div class="row">';


echo '<div class="col-xs-7">';
echo form_submit('submit','Click here to Add this Question','class="btn btn-primary btn-block tn-flat"');



echo "</div></div>";
echo ' </div>
            <!-- /.col -->
            <div class="col-md-6">';

 


echo '<div class="row">';
                
                
  
echo ' <div class="col-xs-6">';
echo ' <label>Maximum Marks</label>';

echo form_input(array(
  'name' => 'maxmark',
  'class' => 'form-control',
  'placeholder'=>'Enter Maximum mark',
  'type' => 'number',
   'min'=>'0',
   'required'=>'TRUE'
));

echo '</div>';


 echo ' <div class="col-xs-6">';
 echo ' <label>Maximum Questions</label>';  
echo form_input(array(
  'name' => 'maxquestion',
  'class' => 'form-control',
  'placeholder'=>'Enter Maximum Questions',
  'type' => 'number',
   'min'=>'0',
   'required'=>'TRUE'
));


echo '</div></div> <br>';


echo '<div class="row">
  <div class="col-xs-6">';
echo ' <label>Marks Per Question</label>';
echo form_input(array(
  'name' => 'mpc',
  'class' => 'form-control',
  'placeholder'=>'Marks per question',
  'type' => 'number',
   'min'=>'0',
   'required'=>'TRUE'
));
echo '</div>';

 echo ' <div class="col-xs-6">';
 echo ' <label>Negative Marks Per Question</label>'; 
echo form_input(array(
  'name' => 'nmpq',
  'class' => 'form-control',
  'placeholder'=>'like .25',
  'type' => 'number',
   'step'=>'any',
   'required'=>'TRUE'
));      

echo '</div></div> <br>';

echo '<div class="row">';
echo ' <div class="col-xs-6">';
echo ' <label>Paper Duration</label>';
echo form_input(array(
  'name' => 'ptime',
  'class' => 'form-control',
  'placeholder'=>'Select Paper Duration',
  'type' => 'time',
   'min'=>'0',
   'required'=>'TRUE'
));         
echo '</div>';
 echo ' <div class="col-xs-6">';
 echo ' <label>Price</label>';
echo form_input('price','0','class="form-control" placeholder="Enter Price" readonly required');         
echo '</div></div> <br>';

echo '<div class="row">';
echo ' <div class="col-xs-6">';
echo ' <label>Paper Start date</label>';
echo form_input(array(
  'name' => 'psd',
  'class' => 'form-control',
  'placeholder'=>'Select start date',
  'type' => 'date',
   'min'=>'0',
   'required'=>'TRUE'
));         
echo '</div>';
 echo ' <div class="col-xs-6">';
 echo ' <label>Paper End Date</label>';
echo form_input(array(
  'name' => 'ped',
  'class' => 'form-control',
  'placeholder'=>'Select end date',
  'type' => 'date',
   'min'=>'0',
   'required'=>'TRUE'
));         
echo '</div></div> <br>';
                
       echo '
<!-- row -->
              
            </div>
            <!-- /.col -->
        ';

echo form_close();
?>


             
           
              
 
               

 




 





  </div>
          <!-- /.row -->


        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          <font color="red">All Required * </font>
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
