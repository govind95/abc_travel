<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        All Questions List
        <small>All category questions included in this List.</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Question List</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
           
          </div>
        </div>
        <div class="box-body">
     
<?php 
if(isset($_GET['deletesuccess'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Requested Question Deactive successfully.';
          echo '</div>';
}
if(isset($_GET['actsuccess'])){

echo '<div class="alert alert-success fade in">';
            echo '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
            echo '<strong>Congraths!</strong> Requested Question Active successfully.';
          echo '</div>';
}
?>
 <table id="example1" class="table table-bordered table-striped">
<thead>
                <tr>
                  <th style="width: 10px">#</th>
                    <th>Question</th>
                    <th>Answer</th>
                    <th>Main Category</th>
                    <th>Sub category</th>
                    <th>Level</th>
                    <th>Status</th>
                  <th style="width: 60px">Actions</th>
                </tr>
               </thead>
<?php $sn=1; foreach($result as $r): ?>
 <tr>
<td><?php echo $sn; ?></td>
                  <td><?php echo $r->questiondetails; ?></td>
                  <td><?php echo $r->answer; ?>  </td>
  <td><?php echo $r->mcname; ?>  </td>
 <td><?php echo $r->scname; ?>  </td>
 <td><?php echo $r->level; ?>  </td>
<td><?php if($r->status==1){ echo '<span class="label label-success">Active</span>';} else {echo '<span class="label label-danger">Deactive</span>';}?>  </td>
<td><a href="questions/fulldetail/<?php echo $r->id; ?>" title="Click here to See full details"><button type="button" class="btn btn-xs bg-maroon">  <span class="glyphicon glyphicon-zoom-in"></span></button></a>
<a href="questions/editquestion/<?php echo $r->id; ?>" title="Click here to edit details"><button type="button" class="btn btn-xs btn-info">  <span class="glyphicon glyphicon-edit"></span></button></a>
<?php if($r->status==1) {?>
<a href="questions/delete/<?php echo $r->id; ?>" title="Click here to Deactive"><button type="button" class="btn btn-xs btn-danger">  <span class="glyphicon glyphicon-ban-circle"></span></button></a>
<?php } else{?>
<a href="questions/active/<?php echo $r->id; ?>" title="Click here to Active"><button type="button" class="btn btn-xs btn-success">  <span class="glyphicon glyphicon-ok"></span></button></a>
<?php } ?>
                  </td>
                </tr>


<?php $sn=$sn+1; endforeach; ?>
                  
                
              </table>











        </div>
        <!-- /.box-body -->
 <div class="box-footer">
          Footer
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
