<?php


defined('BASEPATH') OR exit('No direct script access allowed');
 
    



class Users_model extends CI_Model {

   
function __construct()
    {
        // Call the Model constructor
        parent::__construct();
//$this->load->db;

    }

 /**
    * Validate the login's data with the database
    * @param string $user_name
    * @param string $password
    * @return void
    */




	function validate($email, $password)
	{
$this->load->database();
		$this->db->where('email', $email);
		$this->db->where('password', $password);
		$query = $this->db->get('users');
		//print_r($query);

//echo 'Total Results: ' . $query->num_rows();
		if($query->num_rows() == 1)
		{
			return true;
		}		
	}

   
}

